`timescale 1ns/1ps
module tb_fft_2_sol0_gen1;
    reg clk; reg rst; reg start; wire done;
    reg load_en; reg [0:0] load_addr; reg [15:0] load_data;
    reg unload_en; reg [0:0] unload_addr; wire [15:0] unload_data;
    integer i, ti, out_file;
    integer cycle_count, total_cycles, load_cycles, unload_cycles_cnt;
    reg [15:0] tv [21:0];

    fft_2_sol0_gen1_top dut (
        .clk(clk), .rst(rst), .start(start), .done(done),
        .load_en(load_en), .load_addr(load_addr), .load_data(load_data),
        .unload_en(unload_en), .unload_addr(unload_addr), .unload_data(unload_data)
    );

    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        #27170;
        $display("WATCHDOG TIMEOUT");
        $finish;
    end

    initial begin : STIM
        integer wait_cnt;
        tv[0] = 16'h3600;
        tv[1] = 16'h0000;
        tv[2] = 16'h3600;
        tv[3] = 16'hb600;
        tv[4] = 16'h0000;
        tv[5] = 16'h0000;
        tv[6] = 16'h3600;
        tv[7] = 16'h8036;
        tv[8] = 16'h3600;
        tv[9] = 16'hb680;
        tv[10] = 16'h3600;
        tv[11] = 16'hb600;
        tv[12] = 16'h0000;
        tv[13] = 16'h3600;
        tv[14] = 16'h3600;
        tv[15] = 16'h0000;
        tv[16] = 16'h3600;
        tv[17] = 16'hb680;
        tv[18] = 16'h3600;
        tv[19] = 16'h3600;
        tv[20] = 16'h3600;
        tv[21] = 16'hb680;
        out_file = $fopen("/home/rohan-kamath/Updated-FFT-Processor/sim/fft_2_sol0_gen1_output.txt", "w");
        rst = 0; start = 0; load_en = 0; load_addr = 0; load_data = 0; unload_en = 0; unload_addr = 0; total_cycles = 0;
        repeat(8) @(posedge clk);
        rst = 1;
        repeat(4) @(posedge clk);

        $display("\n================================================================");
        $display("  Pipelined Run Report  --  fft_2_sol0_gen1 (FFT-2)");
        $display("================================================================");

        for (ti = 0; ti < 11; ti = ti + 1) begin
            @(posedge clk);
            load_cycles = 0; load_en = 1;
            for (i = 0; i < 2; i = i + 1) begin
                load_addr = i[0:0]; load_data = tv[ti*2 + i];
                @(posedge clk); load_cycles = load_cycles + 1;
            end
            load_en = 0;
            @(posedge clk); load_cycles = load_cycles + 1;

            cycle_count = 0; start = 1;
            @(posedge clk); start = 0;
            cycle_count = cycle_count + 1;

            wait_cnt = 0;
            while (!done && wait_cnt < 565) begin
                @(posedge clk); cycle_count = cycle_count + 1; wait_cnt = wait_cnt + 1;
            end
            @(posedge clk);

            unload_cycles_cnt = 0; unload_en = 1;
            for (i = 0; i < 2; i = i + 1) begin
                unload_addr = i[0:0];
                @(posedge clk); unload_cycles_cnt = unload_cycles_cnt + 1;
                @(posedge clk); unload_cycles_cnt = unload_cycles_cnt + 1;
                @(posedge clk); unload_cycles_cnt = unload_cycles_cnt + 1;
                $fwrite(out_file, "%04h\n", unload_data);
            end
            unload_en = 0;
            repeat(2) @(posedge clk);
            
            total_cycles = total_cycles + load_cycles + cycle_count + unload_cycles_cnt;
            $display("  -> Test %0d | Exec Cycles: %0d | Load: %0d | Unload: %0d", ti, cycle_count, load_cycles, unload_cycles_cnt);
        end
        $display("================================================================");
        $display("FINAL_METRICS | Total Cycles: %0d", total_cycles);
        $display("================================================================");
        
        $fclose(out_file);
        $finish;
    end
endmodule
